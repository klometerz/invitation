<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e($seo['title'] ?? 'Wedding Maulia & Kahfi'); ?></title>

        <meta property="og:type" content="website">
        <meta property="og:title" content="<?php echo e($seo['title'] ?? 'Wedding Maulia & Kahfi'); ?>">
        <meta property="og:description" content="<?php echo e($seo['description'] ?? 'Anda diundang untuk hadir di acara pernikahan kami.'); ?>">
        <meta property="og:image" content="<?php echo e($seo['image'] ?? url('/mk.png')); ?>">
        <meta property="og:url" content="<?php echo e($seo['url'] ?? url()->current()); ?>">
        <meta name="twitter:card" content="summary_large_image">

        <meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="<?php echo e($seo['title'] ?? 'Wedding Maulia & Kahfi'); ?>">
<meta name="twitter:description" content="<?php echo e($seo['description'] ?? 'Anda diundang untuk hadir di acara pernikahan kami.'); ?>">
<meta name="twitter:image" content="<?php echo e($seo['image'] ?? url('/mk.png')); ?>">

        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>
        <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->head; } ?>
    </head>
    <body class="antialiased">
        <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->body; } elseif (config('inertia.use_script_element_for_initial_page')) { ?><script data-page="app" type="application/json"><?php echo json_encode($page); ?></script><div id="app"></div><?php } else { ?><div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div><?php } ?>
    </body>
</html><?php /**PATH C:\laragon\www\invitation\resources\views/app.blade.php ENDPATH**/ ?>