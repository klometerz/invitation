<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\GuestController;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');
Route::get('/guests/{code}', [GuestController::class, 'show']);
Route::post('/rsvp/{code}', [GuestController::class, 'updateRsvp']);
